package com.example.h_saveme;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class by_town extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_by_town);
    }
}
